<?php
include_once("db-config.php");
session_start();

// // This page can be accessed only after login.
// // Redirects uder to signin page if user email is not available in session.
if(!isset($_SESSION["username"])){
    header("location: main.php?requestid=2");
}
$username=$_SESSION["username"];
    $aadhar_no=$_SESSION["aadhar_no"];
    $full_name=$_SESSION["full_name"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>E-Voting</title>
    <link rel="shortcut icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww">
    <script src="https://platform.linkedin.com/badges/js/profile.js" async defer type="text/javascript"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
</head>
<style>
    .container {
    max-width: 38em;
    padding: 1em 3em 2em 3em;
    margin: 0em auto;
    background-color: #fff;
    border-radius: 4.2px;
    box-shadow: 0px 3px 10px -2px rgba(240, 165, 0, 0.55);
    }


.button{
  
  width: 170px;
  height: 40px;
  font-size: 18px;
  font-weight: bold;
  font-family: 'Ubuntu', sans-serif;
  border: 3px solid #f0a500;
  background: #fff;
  color: #f0a500;
  border-radius: 40px;
  margin-top:10%;
  margin-left:33%;
  
}


    
</style>
<body>
<div>
<marquee><h4>&#128683&#128187Do Not Go back or refresh the site, Doing so will log you out!&#128187&#128683</h4></marquee> 
            <div style='position: relative;
                    right: 0;
                    width: 100%;
                    height:50%;
                    background-color: grey;
                    color: white;
                    text-align: center;'>
                                <p><b>Logged in as : <?php echo"$full_name \t\t ($username)"?> 
                                <form method="post">
                                <input style='background-color: #cafaeb;color:#f0a500;' name='logout' type='submit' value='Logout'> 
                                </b></p></div>
            <?php
                if(isset($_POST["logout"]))
                {
                    // remove all session variables
                    session_unset();

                    // destroy the session
                    session_destroy();
                    echo'
                    <script>alert("USER LOGGED OUT SUCCESSFULLY! ")</script>
                    ';
                    header("location: main.php?requestid=3");
                }
            ?>
            </form>
<div class='container'>
<form>

<label style=' font-size:24px;' for="input_aadhar"><br>Aadhar No. : </label>
<input style=' font-size:20px;' type="username" name="aadhar_no" id="input_aadhar" placeholder="Aadhar No." required autocomplete="off"/>
<br>
<label style=' font-size:24px;' for="input_dob"><br>DOB   &emsp;&emsp;&ensp;&nbsp; :</label>
<input style=' font-size:20px;color:#999;' type="date" id="input_dob" name="dob" required min ="1900-01-01" max="2003-12-31" autocomplete="off"/>
<br>
<input class="button" id="submit" name="submit"  type='submit' value='Submit'/>
<?php
                if(isset($_POST["submit"]))
                {
                     include_once("db-config.php");
                    //  header("location:'https://www.google.com'");
                        // IIIII AAAAAMM HERRRREEEE
                        // $aadhar_no=$_SESSION["aadhar_no"];
                        // $input_aadhar=$_POST["aadhar_no"]
                        // $input_dob=$_POST["input_dob"]
                        // $check=mysqli_query($mysqli,"select DOB from Account_DB where 
                        //         aadhar_no='$aadhar_no'");
                        // $result=mysqli_fetch_object($check);
                        // $vote_check=$result->DOB;
                        // if ($vote_check==$input_dob and $aadhar_no==$input_aadhar){
                        //     echo"<script>alert('okaaaaaayyyy')</script>";
                }
                ?>
</div>
           <script>
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth()+1; //January is 0 so need to add 1 to make it 1!
                var yyyy = today.getFullYear()-18;
                if(dd<10){
                dd='0'+dd
                } 
                if(mm<10){
                mm='0'+mm
                } 
                today = yyyy+'-'+mm+'-'+dd;
                document.getElementById("input_dob").setAttribute("max", today);
           </script>


</form>
</div>





<div style="position: fixed;
  right: 0;
  bottom: 0;
  width: 100%;
  background-color: grey;
  color: white;
  text-align: center;">
<p><b>A project by </b><br><img style="height:80px;width:100;" src="https://drive.google.com/thumbnail?id=1nVdBe9UI1roRVbNnMcLvOxtA41qx6HE3" alt="Brillect Tech Solutions Pvt. Ltd."></p>
<p><b>&copy 2020-21 &reg Brillect Tech. Solutions Pvt. Ltd. </></b></p>
<p ><a style="color:rgb(132, 200, 255);font-size:14px;" href="mailto: me@sumitbakane.codes">Contact &#8644; me@sumitbakane.codes</a></p>
</div>

 <?php
// remove all session variables
session_unset();

// destroy the session
session_destroy();
?>
</div>
</body>
</html>
<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert("Right click is disabled due to security purposes");
        }, false);

</script> 
