<?php
session_start();
include("db-config.php");
$currIP=$_SERVER['REMOTE_ADDR'];
$timestamp=time();
$username=$_SESSION['username'];
$sql = "UPDATE GlobalVotes_DB SET Votes=Votes+1 WHERE Sr_No= '".$_GET["refid"]."'";
$sql2="UPDATE VoteCheck_DB SET vote_check=vote_check+1 , ip='$currIP' , timestamp='$timestamp' WHERE username='$username'";
if (mysqli_query($mysqli, $sql) and mysqli_query($mysqli,$sql2)) {
    // remove all session variables
    session_unset();

    // destroy the session
    session_destroy();
    header("location:thanksPage.php");
    
} else {
    echo "<html><h1>Something Went Wrong!</h1><h2>Please Contact:<a href='mailto:me@sumitbakane.codes'></a><br><a href='mailto:sdlc@brillect.in'></a  </h2> " ;
}
mysqli_close($mysqli);
?>
<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert("Right click is disabled due to security purposes");
        }, false);

</script> 