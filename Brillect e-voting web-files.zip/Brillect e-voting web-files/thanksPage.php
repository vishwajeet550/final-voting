<!DOCTYPE html>
<html lang="en">
<head>
    <title>E-Voting</title>
    <link rel="shortcut icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww">
    <script src="https://platform.linkedin.com/badges/js/profile.js" async defer type="text/javascript"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
</head>
<body>
<p style='font-size: 55px; text-align: center;color:#fc9631;'><br><br><br><b>Thanks for Voting!</b></p>
<div style="position: fixed;
  right: 0;
  bottom: 0;
  width: 100%;
  background-color: grey;
  color: white;
  text-align: center;">
<p><b>A project by </b><br><img style="height:80px;width:100;" src="https://drive.google.com/thumbnail?id=1nVdBe9UI1roRVbNnMcLvOxtA41qx6HE3" alt="Brillect Tech Solutions Pvt. Ltd."></p>
<p><a style="color:white;" href="https://www.brillect.in"><b>&copy 2020-21 &reg Brillect Tech. Solutions Pvt. Ltd. </b></a></p>
<a style="color:rgb(132, 200, 255);font-size:14px;" href="mailto: me@sumitbakane.codes">Contact &#8644; me@sumitbakane.codes</a>
</div>
</body>
<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert('Right click is disabled due to security purposes');
        }, false);
      
</script> 
<?php
// remove all session variables
    session_unset();

    // destroy the session
    session_destroy();
    ?>