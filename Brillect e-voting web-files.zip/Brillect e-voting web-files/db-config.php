<?php

$databaseHost = 'sql308.epizy.com';
$databaseName = 'epiz_28715794_brillect_evoting';
$databaseUsername = 'epiz_28715794';
$databasePassword ='jqhL2USQx76egp';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>