styles.css is the file which contains all css elements and handles the UI of the webpage

main.html is the file containing form html data of first page/ page which has user signin form.

actionpage.php is file which checks if user has already submitted the vote or NOT!

form.php is used to check the reCaptcha validation and handles redirections as disscused below:-
            @ if reCaptcha is successfully validated, user automatically redirects to actionpage.php within 2 seconds
            @ if reCaptcha is incorrect, user automatically redirects to same sign-in within 5 seconds
            @ if reCaptcha detects any spammer activity, user automatically redirects to same sign-in within 5 seconds

db-config.php is the file used to store all variables related to mySQL connectivity.

getDetailsPage.php is the page which is depreciated for now and was build to give user the details about his/her voting.

votePage.php lets user to vote on respective contestant.

VoteSubmit.php updates the database as per the vote submitted by the user'

thanksPage.php is the last page of the website which displays the thanks message to the voter......