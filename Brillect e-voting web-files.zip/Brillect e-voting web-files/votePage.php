<?php
include_once("db-config.php");
session_start();

// // This page can be accessed only after login.
// // Redirects uder to signin page if user email is not available in session.
if(!isset($_SESSION["username"])){
    header("location: main.php?requestid=2");
}
include_once("db-config.php");
 $username=$_SESSION["username"];
    $aadhar_no=$_SESSION["aadhar_no"];
    $full_name=$_SESSION["full_name"];
    $check=mysqli_query($mysqli,"select * from VoteCheck_DB where 
            username='$username' and aadhar_no='$aadhar_no'");
    $result=mysqli_fetch_object($check);
    $vote_check=(int)$result->vote_check;

    if ($vote_check>0){
        header("location: actionpage.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>E-Voting</title>
    <link rel="shortcut icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww">
    <script src="https://platform.linkedin.com/badges/js/profile.js" async defer type="text/javascript"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
</head>
<style>
        .rawbut {
            font-size: 1.3rem;
            padding: 1em 2em;
            margin: 0em;
            display: inline-block;
            border-radius: 4em;
            border: solid transparent;
            background: linear-gradient(0deg,#ff6064, #ff9867), linear-gradient(0deg,#ff6064, #ff9867);
            color: #ff6064;
            background-clip: border-box, text;
            background-position: center center;
            box-shadow: inset 0 0 0 100px white;
            background-size: 110% 110%;
        }
table {
            text-align: center;
            width:80%;
            margin: 10px auto;
            }

            caption {
                
                text-align: center;
            font-size: 1.6em;
            font-weight: 400;
            padding: 10px 0;
            }

            thead th {
                text-align: center;
            border-right: 1px solid white;
            font-weight: 400;
            background: #ffd8cc;
            color: #525252;
            }

            tr {
                border-right: 1px solid white;
                text-align: center;
            background: #f4f7f8;
            border-bottom: 2px solid #ffc8b8;
            margin-bottom: 5px ;
            }

            tr:nth-child(even) {
                text-align: center;
            background: #e8eeef;
            }

            th, td {
                border-right: 1px solid white;
                text-align: center;
            padding: 20px;
            font-weight: 300;
            }

            tfoot tr {
                text-align: center;
            background: none;
            }

            tfoot td {
                text-align: center;
            padding: 10px 2px;
            font-size: 0.8em;
            font-style: italic;
            color: #8a97a0;
            }
            img {
            pointer-events: none;
            }
</style>



<body>
<div>
<!-- header-->
<marquee><h4>&#128683&#128187Do Not Go back or refresh the site, Doing so will log you out!&#128187&#128683</h4></marquee> 
            <div style='position: relative;
                    right: 0;
                    width: 100%;
                    height:50%;
                    background-color: grey;
                    color: white;
                    text-align: center;'>
                                <p><b>Logged in as : <?php echo"$full_name \t\t ($username)"?> 
                                <form method="post">
                                <input style='background-color: #cafaeb;color:#f0a500;' name='logout' type='submit' value='Logout'> 
                                </b></p></div>
                <?php
                    if(isset($_POST["logout"]))
                    {
                        echo'
                        <script>alert("USER LOGGED OUT SUCCESSFULLY! ")</script>
                        ';
                        // remove all session variables
                        session_unset();

                        // destroy the session
                        session_destroy();
                        
                        header("location: main.php?requestid=3");
                    }
                ?>
                </form>

<table text-align="center" >
    
    <caption>E-Voting </caption>
      <thead>
      <tr>
        <th scope="col">Sr. No.</th>
        <th scope="col">Name of Contestant</th>
        <th scope="col">Symbol</th>
        <th scope="col">Click to Vote</th>
      </tr>
      </thead>
      <tfoot>
        <tr>
        <td colspan="3">*You will get only one chance to Vote<br/></td>
          <td colspan="3">**Do not refresh.</td>
        </tr>
      </tfoot>
      <?php  
            function  createConfirmationmbox() {  
                echo '<script type="text/javascript"> ';  
                echo ' function openulr(newurl) {';  
                echo '  if (confirm("Are you sure you want to submit your Ballot ?")) {';  
                echo '    document.location = newurl;';  
                echo '  }';  
                echo '}';  
                echo '</script>';  
            }  
            ?>  
      <?php
        
        


        $table='GlobalVotes_DB';
        $result=$mysqli->query("SELECT * FROM $table ") or die($mysqli->error); 
        while($data = $result->fetch_assoc()){
            $Sr_No= $data['Sr_No'];
            $C_symbol= $data['C_symbol'];
            $C_name= $data['C_name'];
            
            ?>
                    
            <tbody>
                <tr>
                    <td scope="row"> <strong><?php echo $Sr_No; ?></strong></td>
                    <td scope="row"> <strong><?php echo $C_name; ?></strong></td>
                    <td><a><img src="<?php echo 'Symbols/'.$C_symbol;?>"width="100px" style="visible:hidden" height="100px"/></a></td>
                    <?php  
                        createConfirmationmbox();  
                    ?>
                    <td scope="row"><a class="rawbut" href="javascript:openulr('voteSubmit.php?refid=<?php echo $Sr_No; ?>');">Click to Vote</a> </td>
                    
                    
                </tr>
                </tbody>
        
            
            <?php

            }

            ?>
            </table>

    <tbody>
        
</tbody>
 
 

<!-- Footer-->

<div style="position: relative;
  right: 0;
  bottom: 0;
  width: 100%;
  background-color: grey;
  color: white;
  text-align: center;">
<p><b>A project by </b><br><img style="height:80px;width:100;" src="https://drive.google.com/thumbnail?id=1nVdBe9UI1roRVbNnMcLvOxtA41qx6HE3" alt="Brillect Tech Solutions Pvt. Ltd."></p>
<p><b>&copy 2020-21 &reg Brillect Tech. Solutions Pvt. Ltd. </></b></p>
<p ><a style="color:rgb(132, 200, 255);font-size:14px;" href="mailto: me@sumitbakane.codes">Contact &#8644; me@sumitbakane.codes</a></p>
</div>

 
</div>
</body>
</html>
<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert("Right click is disabled due to security purposes");
        }, false);

</script> 