

<head>
    <title>E-Vote</title>
    <link rel="shortcut icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src='https://www.google.com/recaptcha/api.js' async defer></script>
</head>
<style>
.button {
  border-radius: 4px;
  background-color: #f0a500;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 18px;
  padding: 10px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
.buttonBefore {
  border-radius: 4px;
  background-color: #e8b589;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 18px;
  padding: 10px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}
div {
  -webkit-user-select: none; /* Safari */
  -ms-user-select: none; /* IE 10 and IE 11 */
  user-select: none; /* Standard syntax */
}
</style>
</head>



<body>
<div class="container">
    <h1 style=";
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  color:#fc9631;
  position: relative;
  letter-spacing:.08em;
  z-index: 2;
  font-size: 2em;
  text-transform: uppercase;
  text-shadow: 1px 1px #fc9631,
               2px 2px #fb8a18,
               3px 3px #f67d04,
               10px 10px 30px rgba(0,0,0,.4)">E-Voting System</h1>

    <?php
        if($_GET['requestid']==2){
            echo'
                <script>alert("USER AUTHENTICATION FAILED! \nPlease Sign-In with correct Details !")</script>
                ';
        }
        if($_GET['requestid']==3){
            echo'
                <script>alert("USER LOGGED OUT SUCCESSFULLY! ")</script>
                ';
        }
    ?>
    <marquee>Input fields are <b>CASE-SENSITIVE</b>,Please Fill the correct information as provided by <b>ADMIN</b>! </marquee>

  <form action="form.php" method="post" id="voteform" autocomplete="off">
    <div class="row">
      <h4>Account</h4>
      <div class="input-group input-group-icon">
        <input type="username" name="username" placeholder="Username" required autocomplete="off"/>
        <div class="input-icon">&nbsp;<i class="fa fa-envelope"></i></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="password" placeholder="Password" name="password" required autocomplete="off"/>
        <div class="input-icon">&nbsp;<i class="fa fa-key"></i></div>
      </div>
    </div>
    <div class="row">
      <div class="col-half">
        <h4>Date of Birth</h4>
        <div class="input-group">
            <input style="color:#999; opacity:1" type="date" id="datefield" name="dob" required min ="1900-01-01" max="2003-12-31" autocomplete="off"/>
           <script>
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth()+1; //January is 0 so need to add 1 to make it 1!
                var yyyy = today.getFullYear()-18;
                if(dd<10){
                dd='0'+dd
                } 
                if(mm<10){
                mm='0'+mm
                } 
                today = yyyy+'-'+mm+'-'+dd;
                document.getElementById("datefield").setAttribute("max", today);
           </script>
        </div>
      </div>
      <div class="col-half">
        <h4>Gender</h4>
        <div class="input-group" >
          <input id="gender-male" type="radio" name="gender" value="M" required autocomplete="off"/>
          <label for="gender-male">Male</label>
          <input id="gender-female" type="radio" name="gender" value="F" required autocomplete="off"/>
          <label for="gender-female">Female</label>
        </div>
      </div>
    </div>
    <div class="row">
      <h4>Identification Details</h4>
      <div class="input-group">
        <input id="aadhar-card" type="radio" name="aadhar" value="card" checked="true" required autocomplete="off"/>
        <label for="aadhar-card"><span><i class="fa fa-id-card-o "></i>Aadhar Card</span></label>
      </div>
      <div class="input-group input-group-icon">
        <input type="number" name="UIN" placeholder="Unique Identification Number (UIN)" required autocomplete="off"/>
        <div class="input-icon">&nbsp;<i class="fa fa-credit-card"></i></div>
      </div>
      <div class="new-col">
        <div class="input-group input-group-icon">
          <input type="text" placeholder="Full-Name on ID  (Case Sensitive)" name="full_name" required autocomplete="off"/>
          <div class="input-icon">&nbsp;<i class="fa fa-user"></i></div>
        </div>
      </div>
    </div>
    <div class="row">
      <h4>Terms and Conditions</h4>
      <div class="input-group">
        <input id="terms" type="checkbox" required autocomplete="off"/>
        <label style="color:black;" for="terms">I accept the terms and conditions for using this service, and hereby confirm I have read the privacy policy.</label>
      </div>
    </div>
    
    
    <input class="button" type="submit" name="submit" form="voteform" id="submitBTN" value="Submit"></button>
  </form>


</div>
</body>
<div style="position: relative;
  right: 0;
  bottom: 0;
  width: 100%;
  background-color: grey;
  color: white;
  text-align: center;">
<p><b>A project by </b><br><img style="height:50;width:100;" src="https://drive.google.com/thumbnail?id=1nVdBe9UI1roRVbNnMcLvOxtA41qx6HE3" alt="Brillect Tech Solutions Pvt. Ltd."></p>
<p><b><a style="color:white;" href="http://www.brillect.in">&copy 2020-21 &reg Brillect Tech. Solutions Pvt. Ltd. </a></b></p>
<p style="color:rgb(132, 200, 255);font-size:14px;">Contact &#8644; <a style="font-size:14px; color:rgb(132, 200, 255);" href="mailto: me@sumitbakane.codes">me@sumitbakane.codes</a></p>
</div>

<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert("Right click is disabled due to security purposes");
        }, false);

        // // after successful recaptcha this js function enables the submit button
        //  function enableBtn(){
        // document.getElementById("submitBTN").disabled = false;
        // document.getElementById("submitBTN").setAttribute("class","button")
        // document.getElementById("submitBTN").setAttribute("value","Submit")
        // }
</script> 
