<html>
<head>
    <title>Captcha Verify</title>
    <link rel="shortcut icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
    body {
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    }
</style>
</html>
<?php
include_once("db-config.php");
// starting session so that only registered user can access further content
session_start();
$username;$password;$dob;$gender;$UIN;$full_name;$captcha;


// IF form submitted, collect all the details from form
        if(isset($_POST['submit'])){
          $username=$_POST['username'];
          $password=$_POST['password'];
          $dob=$_POST['dob'];
          $gender=$_POST['gender'];
          $UIN=(int)$_POST['UIN'];
          $full_name=$_POST['full_name'];

        //   check if user exists with given credentials
        $check=mysqli_query($mysqli,"select * from Account_DB where 
            username='$username' and password='$password' and DOB='$dob' and gender='$gender' and aadhar_no='$UIN' and full_name='$full_name'");

        // count the number of user/rows returned t=by check query
        $user_matched=mysqli_num_rows($check);
        
        
        
        // if user exist/matched, allow user to access next page..
        if ($user_matched==1){
            $_SESSION["username"]=$username;
            $_SESSION["aadhar_no"]=$UIN;
            $_SESSION["full_name"]=$full_name;
            // header("location: actionpage.php");
            echo"<html><body><h1 style='text-align: center;color:#fc9631;'>User Verified Successfully!</h1></body></html>";
            echo"<html><body><p style='text-align: center;color:#000;'>Automatically redirecting to Voting Page in <b><span id='sec'></span></b> Seconds!</p></body></html><script>
                var limit=2;
                var x = setInterval(function() {
                if(limit<0){
                    clearInterval(downloadTimer);
                    }
                    document.getElementById('sec').innerHTML = limit;
                    limit-=1
                }, 1000);
                </script>";
            
            header("Refresh: 4; URL=actionpage.php");
             exit;
            

        }else{
            // requestid is used in order to display alert msg to user about authentication failure! which is then hardcoded in main signin page.
            header("location: main.php?requestid=2");
        }
        
        }
        

            
        

echo"<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert('Right click is disabled due to security purposes');
        }, false);
      
</script> ";


?>

<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert("Right click is disabled due to security purposes");
        }, false);

</script> 