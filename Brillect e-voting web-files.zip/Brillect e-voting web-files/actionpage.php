 <?php
include_once("db-config.php");
session_start();

// // This page can be accessed only after login.
// // Redirects uder to signin page if user email is not available in session.
if(!isset($_SESSION["username"])){
    header("location: main.php?requestid=2");
}
$username=$_SESSION["username"];
    $aadhar_no=$_SESSION["aadhar_no"];
    $full_name=$_SESSION["full_name"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>E-Voting</title>
    <link rel="shortcut icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww" type="image/x-icon">
    <link rel="apple-touch-icon" href="https://drive.google.com/thumbnail?id=1jLXz76xr7_LX5VINfg6H8eelNs0fJCww">
    <script src="https://platform.linkedin.com/badges/js/profile.js" async defer type="text/javascript"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
</head>
<style>
// restricting user to select elements such as texts, links,images from document
    div{
    -webkit-user-select: none; /* Safari */
    -ms-user-select: none; /* IE 10 and IE 11 */
    user-select: none; /* Standard syntax */
    }
    @import url("https://fonts.googleapis.com/css?family=Montserrat");
    .aButton {
        position: relative;
        left: 50%;
        top:150px;
        transform: translate(-50%, -50%);
        color: #f0a500;
        text-decoration: none;
        font-size: 2em;
        display: inline-block;
        font-family: Montserrat;
        text-transform: uppercase;
        padding: 0.5em 2em;
        border: 2px solid #f0a500;
        transition: 0.02s 0.2s cubic-bezier(0.1, 0, 0.1, 1);
    }
    .aButton::before {
        content: "";
        display: inline-block;
        position: absolute;
        top: 0;
        left: 0;
        right: 100%;
        bottom: 0;
        background: #f0a500;
        transition: 0.3s 0.2s cubic-bezier(0.1, 0, 0.1, 1), left 0.3s cubic-bezier(0.1, 0, 0.1, 1);
        z-index: -1;
    }
    .aButton::after {
        content: "";
        display: inline-block;
        background-image: url("https://image.flaticon.com/icons/png/128/109/109617.png");
        position: absolute;
        top: 0;
        left: calc(100% - 3em);
        right: 3em;
        bottom: 0;
        background-size: 1.5em;
        background-repeat: no-repeat;
        background-position: center;
        transition: right 0.3s cubic-bezier(0.1, 0, 0.1, 1);
    }
    .aButton:hover {
        padding: 0.5em 3.5em 0.5em 0.5em;
    }
    .aButton:hover::before {
        left: calc(100% - 3em);
        right: 0;
        transition: 0.3s cubic-bezier(0.1, 0, 0.1, 1), left 0.3s 0.2s cubic-bezier(0.1, 0, 0.1, 1);
    }
    .aButton:hover::after {
        right: 0;
        transition: right 0.3s 0.2s cubic-bezier(0.1, 0, 0.1, 1);
    }
   
</style>
<body>
<div>
<marquee><h4>&#128683&#128187Do Not Go back or refresh the site, Doing so will log you out!&#128187&#128683</h4></marquee> 
            <div style='position: relative;
                    right: 0;
                    width: 100%;
                    height:50%;
                    background-color: grey;
                    color: white;
                    text-align: center;'>
                                <p><b>Logged in as : <?php echo"$full_name \t\t ($username)"?> 
                                <form method="post">
                                <input style='background-color: #cafaeb;color:#f0a500;' name='logout' type='submit' value='Logout'> 
                                </b></p></div>
            <?php
                if(isset($_POST["logout"]))
                {
                    // remove all session variables
                    session_unset();

                    // destroy the session
                    session_destroy();
                    echo'
                    <script>alert("USER LOGGED OUT SUCCESSFULLY! ")</script>
                    ';
                    header("location: main.php?requestid=3");
                }
            ?>
            </form>
                                
<?php
    include_once("db-config.php");
    $username=$_SESSION["username"];
    $aadhar_no=$_SESSION["aadhar_no"];
    $full_name=$_SESSION["full_name"];
    $check=mysqli_query($mysqli,"select vote_check from VoteCheck_DB where 
            username='$username' and aadhar_no='$aadhar_no'");
    $result=mysqli_fetch_object($check);
    $vote_check=(int)$result->vote_check;
    if ($vote_check==0){
        
        echo "
            <html>
                <body>

                    <h2 style='text-align: center; position:relative;'>
                    <br>
                        Seems like you are Ready to vote..
                        <br><h3 style='position:relative; text-align: center'>Click the 'Vote Now' Button below to go to voting Console</h3>
                    </h2>

                    <a class='aButton' style='position:relative; color:#f0a500;' href='votePage.php'>Vote Now</a>

                </body>
            </html> ";
    }else{
        echo "
            <html>
                <body>
                    <h2 style='text-align: center'>
                    <br>
                        Seems like you have already <b><i>submitted your vote</b></i>
                        <br><br><h3 style='text-align: center'>
                            In case of any discrepancies, please <b><u><a href='mailto:sdlc@brillect.in'>Contact : sdlc@brillect.in </a></u></b>
                            </h3>
                    </h2>
                   
                </body>
            </html> ";
    }
?>
<div style="position: fixed;
  right: 0;
  bottom: 0;
  width: 100%;
  background-color: grey;
  color: white;
  text-align: center;">
<p><b>A project by </b><br><img style="height:80px;width:100;" src="https://drive.google.com/thumbnail?id=1nVdBe9UI1roRVbNnMcLvOxtA41qx6HE3" alt="Brillect Tech Solutions Pvt. Ltd."></p>
<p><a style="color:white;" href="https://www.brillect.in"><b>&copy 2020-21 &reg Brillect Tech. Solutions Pvt. Ltd. </b></a></p>
<a style="color:rgb(132, 200, 255);font-size:14px;" href="mailto: me@sumitbakane.codes">Contact &#8644; me@sumitbakane.codes</a>
</div>


</div>
</body>
</html>
<script>
        // disabling right click
        window.addEventListener('contextmenu', function (e) { 
        e.preventDefault(); 
        alert("Right click is disabled due to security purposes");
        }, false);

</script> 
